# Orb

A Pen created on CodePen.io. Original URL: [https://codepen.io/jscottsmith/pen/oWyxjp](https://codepen.io/jscottsmith/pen/oWyxjp).

Siri-like orb thingy. Mouse over to control min/max phase range.